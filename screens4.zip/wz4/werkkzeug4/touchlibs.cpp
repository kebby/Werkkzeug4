/*+**************************************************************************/
/***                                                                      ***/
/***   Copyright (C) by Dierk Ohlerich                                    ***/
/***   all rights reserverd                                               ***/
/***                                                                      ***/
/***   To license this software, please contact the copyright holder.     ***/
/***                                                                      ***/
/**************************************************************************+*/

#include "base/types.hpp"
#include "base/system.hpp"

/****************************************************************************/
/*
#if sCONFIG_SDK_TC3
sDInt TouchLibVal;
void AddOps_tc3_mesh_ops();
void AddOps_tc3_misc_ops();
void TouchLib()
{
  TouchLibVal += sDInt(AddOps_tc3_mesh_ops);
  TouchLibVal += sDInt(AddOps_tc3_misc_ops);
}

sADDSUBSYSTEM(TouchLib,0xff,TouchLib,0);
#endif

*/
/****************************************************************************/

