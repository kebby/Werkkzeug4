Farbrausch Werkkzeug4 and Screens4
==================================

This is a fork of the "official" altona_wz4 repo with the goal to get a working version of 
Werkkzeug4 and Screens4 (The Partymeister beam system for Revision etc.) into the future. 
The original projects are getting harder and harder to run or even build, so I took the 
sources and set up a completely new project structure that's free from legacy stuff.

So, build requirements: Windows 10 and Visual Studio 2017 or newer. That's it.

Everything else is yet to come.

