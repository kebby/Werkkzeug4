// no include guards to support including this file
// more than once in the same file.

#ifdef _MSC_VER
  #pragma warning (default : 4244)   // enable float to int warnings
#endif
