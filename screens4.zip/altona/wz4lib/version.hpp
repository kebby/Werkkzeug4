/****************************************************************************/

#ifndef FILE_WZ4LIB_VERSION_HPP
#define FILE_WZ4LIB_VERSION_HPP

#include "base/types.hpp"

/****************************************************************************/

#define WZ4_VERSION 0
#define WZ4_REVISION 211

/****************************************************************************/

#endif // FILE_WZ4LIB_VERSION_HPP

