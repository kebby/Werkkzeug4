/*+**************************************************************************/
/***                                                                      ***/
/***   Copyright (C) by Dierk Ohlerich                                    ***/
/***   all rights reserverd                                               ***/
/***                                                                      ***/
/***   To license this software, please contact the copyright holder.     ***/
/***                                                                      ***/
/**************************************************************************+*/

#ifndef FILE_WERKKZEUG4_MAIN_HPP
#define FILE_WERKKZEUG4_MAIN_HPP

#include "base/types.hpp"

/****************************************************************************/



/****************************************************************************/

#endif // FILE_WERKKZEUG4_MAIN_HPP

